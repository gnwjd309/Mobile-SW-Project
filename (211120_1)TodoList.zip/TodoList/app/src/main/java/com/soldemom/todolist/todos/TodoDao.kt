package com.soldemom.todolist.todos

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.room.*

@Dao
interface TodoDao {

    @Query("select * from Todo order by registerTime desc")
    fun getAll() : MutableList<Todo>

    @Query("select * from todo order by date, time desc")
    fun getAllTimeOrder() : MutableList<Todo>

    @Query("select * from todo where text like '%' ||:text || '%' order by date,time desc")
    fun getTodosByText(text: String) : MutableList<Todo>

    @Insert
    fun insert(todo: Todo)

    @Update
    fun update(todo: Todo)

    @Delete
    fun delete(todo: Todo)

    @Delete
    fun deleteAll(vararg todo: Todo)


}